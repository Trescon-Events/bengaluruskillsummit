<?php
function display_konfhub_speakers() {
    $event_slug = 'hodl-summit';
    $api_url = "https://api.konfhub.com/event/public/{$event_slug}/speakers";

    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) {
        return '<p>Error fetching speakers.</p>';
    }

    $body = wp_remote_retrieve_body($response);
    $speakers = json_decode($body, true);
    if (!is_array($speakers)) {
        return '<p>No speakers found.</p>';
    }

    $output = '<div class="speakers-section"><div class="speakers-grid">';

    foreach ($speakers as $sp) {
        $id = $sp['speaker_id'];
        $photo = !empty($sp['image_url']) ? esc_url($sp['image_url']) : 'https://via.placeholder.com/220x220?text=Speaker';
        $name = isset($sp['name']) ? esc_html($sp['name']) : 'Unnamed';
        $designation = isset($sp['designation']) ? esc_html($sp['designation']) : '';
        $org = isset($sp['organisation']) ? esc_html($sp['organisation']) : '';
        $about = !empty($sp['about']) ? $sp['about'] : '<p>No bio available.</p>';
        $linkedin = !empty($sp['linkedin_url']) ? esc_url($sp['linkedin_url']) : '';

        // Sessions
        $session_titles = '';
        if (!empty($sp['sessions']) && is_array($sp['sessions'])) {
            foreach ($sp['sessions'] as $session) {
                $session_titles .= '<li>' . esc_html($session['session_title']) . '</li>';
            }
        }

        // Tags (optional)
        $tag_list = '';
        if (!empty($sp['tags']) && is_array($sp['tags'])) {
            $tag_list .= '<div class="speaker-tags">';
            foreach ($sp['tags'] as $tag) {
                $tag_list .= '<span class="tag">' . esc_html($tag) . '</span> ';
            }
            $tag_list .= '</div>';
        }

        // Speaker card
        $output .= "<div class='speaker-card-wrapper' onclick='showSpeakerPopup({$id})'>";
        $output .= '<div class="speaker-card">';
        $output .= "<img src='{$photo}' alt='{$name}' class='speaker-photo'>";
        $output .= "<h3 class='speaker-name'>{$name}</h3>";
        $output .= "<p class='speaker-title'>{$designation}</p>";
        $output .= "<p class='speaker-org'>{$org}</p>";
        $output .= '</div></div>';

        // Modal popup
        $output .= "<div id='popup-{$id}' class='speaker-modal'>
            <div class='modal-content'>
                <span class='close-modal' onclick='closeSpeakerPopup()'>&times;</span>
                <div class='modal-header'>
                    <img src='{$photo}' class='modal-image' alt='{$name}'>
                    <div class='modal-header-text'>
                        <h2 class='modal-name'>{$name}</h2>
                        <p class='modal-role'>{$designation}" . ($org ? " <span class='modal-org'>@ {$org}</span>" : "") . "</p>";
        if ($linkedin) {
            $output .= "<a href='{$linkedin}' class='modal-linkedin' target='_blank'>🔗 LinkedIn</a>";
        }
        $output .= "</div></div>"; // close modal-header & text
        $output .= $tag_list;
        $output .= "<div class='modal-body'>{$about}</div>";
        if ($session_titles) {
            $output .= "<h4 class='modal-sessions-heading'>Sessions</h4><ul class='modal-sessions'>{$session_titles}</ul>";
        }
        $output .= "</div></div>"; // close modal-content & modal
    }

    $output .= '</div></div>'; // close grid

    // CSS and JS
    $output .= '
    <style>
    /* Container */
    .speakers-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 24px;
    justify-content: flex-start;
    padding: 0 12px;
    margin: 0 auto;
    }

    /* Card wrapper - controls responsive width */
    .speaker-card-wrapper {
    flex: 1 1 calc(25% - 24px); /* 4 per row */
    max-width: calc(25% - 24px);
    box-sizing: border-box;
    cursor: pointer;
    }

    @media (max-width: 1024px) {
    .speaker-card-wrapper {
        flex: 1 1 calc(33.33% - 24px); /* 3 per row on tablets */
        max-width: calc(33.33% - 24px);
    }
    }

    @media (max-width: 768px) {
    .speaker-card-wrapper {
        flex: 1 1 calc(50% - 24px); /* ✅ 2 per row on mobile */
        max-width: calc(50% - 24px);
    }
    }

    @media (max-width: 480px) {
    .speaker-card-wrapper {
        flex: 1 1 100%; /* 1 per row on small screens */
        max-width: 100%;
    }
    }

    /* Card */
    .speaker-card {
    width: 100%;
    text-align: center;
    border: 1px solid #eee;
    border-radius: 10px;
    padding: 15px;
    background: #fff;
    transition: transform 0.2s ease;
    }

    .speaker-card:hover {
    transform: translateY(-5px);
    }

    .speaker-photo {
    width: 100%;
    height: 220px;
    object-fit: cover;
    border-radius: 10px;
    }

    .speaker-name {
    font-size: 18px;
    font-weight: bold;
    margin-top: 10px;
    }

    .speaker-title,
    .speaker-org {
    font-size: 14px;
    color: #555;
    }

    /* Modal */
    .speaker-modal {
    display: none;
    position: fixed;
    z-index: 9999;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    overflow-y: auto;
    padding: 60px 20px;
    }

    .modal-content {
    max-width: 640px;
    margin: auto;
    background: #fff;
    border-radius: 16px;
    padding: 30px;
    position: relative;
    box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
    animation: fadeIn 0.3s ease;
    }

    @keyframes fadeIn {
    from {
        opacity: 0;
        transform: scale(0.95);
    }
    to {
        opacity: 1;
        transform: scale(1);
    }
    }

    .close-modal {
    position: absolute;
    top: 15px;
    right: 20px;
    font-size: 24px;
    font-weight: bold;
    color: #555;
    cursor: pointer;
    }

    .modal-header {
    display: flex;
    flex-direction: row;
    align-items: center;
    gap: 20px;
    flex-wrap: wrap;
    }

    .modal-image {
    width: 120px;
    height: 120px;
    border-radius: 10px;
    object-fit: cover;
    flex-shrink: 0;
    }

    .modal-header-text {
    flex: 1;
    min-width: 0;
    }

    .modal-name {
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 6px;
    }

    .modal-role {
    font-size: 15px;
    color: #444;
    margin-bottom: 4px;
    }

    .modal-org {
    color: #888;
    font-weight: normal;
    }

    .modal-linkedin {
    display: inline-block;
    margin-top: 8px;
    font-size: 14px;
    text-decoration: none;
    color: #0077b5;
    }

    .modal-body {
    margin-top: 20px;
    font-size: 15px;
    color: #333;
    line-height: 1.6;
    }

    .modal-sessions-heading {
    margin-top: 25px;
    font-size: 16px;
    font-weight: 600;
    }

    .modal-sessions {
    padding-left: 20px;
    }

    .modal-sessions li {
    margin-bottom: 6px;
    }

    .speaker-tags {
    margin-top: 15px;
    }

    .speaker-tags .tag {
    display: inline-block;
    background: #f2f2f2;
    padding: 4px 10px;
    font-size: 12px;
    border-radius: 8px;
    margin-right: 5px;
    }
    </style>


    <script>
    function showSpeakerPopup(id) {
        document.getElementById("popup-" + id).style.display = "block";
        document.body.classList.add("popup-open");
    }
    function closeSpeakerPopup() {
        document.querySelectorAll(".speaker-modal").forEach(p => p.style.display = "none");
        document.body.classList.remove("popup-open");
    }
    document.addEventListener("keydown", function(e) {
        if (e.key === "Escape") closeSpeakerPopup();
    });
    </script>';

    return $output;
}
add_shortcode('konfhub_speakers_dynamic', 'display_konfhub_speakers');